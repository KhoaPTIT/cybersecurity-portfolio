<?php
require __DIR__ . '/page/header.php';

$page = isset($_GET['page']) ? $_GET['page'] : 'home';
include __DIR__ . '/modules/' . $page . '.php';

require __DIR__ . '/page/footer.php';

