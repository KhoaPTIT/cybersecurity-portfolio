<?php
$msg = ''; $path = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['photo'])) {
  $name = isset($_FILES['photo']['name']) ? basename($_FILES['photo']['name']) : '';
  $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));

  if (!in_array($ext, array('jpg','jpeg','png','gif'))) {
    $msg = 'Chỉ nhận JPG/PNG/GIF.';
  } else {
    $tmp  = isset($_FILES['photo']['tmp_name']) ? $_FILES['photo']['tmp_name'] : '';
    $dest = __DIR__ . '/../uploads/' . $name;
    if ($tmp && is_uploaded_file($tmp) && move_uploaded_file($tmp, $dest)) {
      $msg = 'Tải lên thành công.';
      $path = '/uploads/' . $name;
    } else {
      $msg = 'Tải lên thất bại.';
    }
  }
}
?>
<h2>Upload</h2>
<?php if ($msg): ?>
  <p><?php echo htmlspecialchars($msg, ENT_QUOTES, 'UTF-8'); ?><?php echo $path ? ' — <code>'.htmlspecialchars($path, ENT_QUOTES, 'UTF-8').'</code>' : ''; ?></p>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
  <input type="file" name="photo" accept=".jpg,.jpeg,.png,.gif" required>
  <button>Tải lên</button>
</form>

<?php if ($path): ?>
  <p><img src="<?php echo htmlspecialchars($path, ENT_QUOTES, 'UTF-8'); ?>" style="max-width:320px"></p>
<?php endif; ?>
