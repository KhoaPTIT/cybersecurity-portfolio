<?php
$dir = __DIR__ . '/../uploads';
if (!is_dir($dir)) { echo "<p>No uploads directory.</p>"; return; }
$files = array_values(array_filter(scandir($dir), function($f){
  return $f !== '.' && $f !== '..';
}));
rsort($files); // mới nhất trước
echo "<h2>Gallery</h2>";
if (!$files) { return; }
echo "<div>";
foreach ($files as $f) {
  $src = '/uploads/' . $f;
  $safe = htmlspecialchars($src, ENT_QUOTES, 'UTF-8');
  echo "<div style='display:inline-block;margin:8px;text-align:center'>
          <img src='{$safe}' style='max-width:200px;display:block'>
          <div style='font-size:12px;color:#666'>" . htmlspecialchars($f) . "</div>
        </div>";
}
echo "</div>";
