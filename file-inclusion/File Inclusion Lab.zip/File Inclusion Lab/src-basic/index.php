<?php
require __DIR__ . '/page/header.php';

$page = $_GET['page'] ?? 'modules/home.php';

$scheme = parse_url($page, PHP_URL_SCHEME);

if ($scheme === 'expect') {
    $h = @fopen($page, 'r');
    if ($h) {
        echo stream_get_contents($h);
        fclose($h);
    } else {
        echo "Failed to open expect stream.";
    }
} else {
    include $page;
}

require __DIR__ . '/page/footer.php';
