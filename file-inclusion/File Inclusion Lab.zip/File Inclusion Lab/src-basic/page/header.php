<?php ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Photo Board</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: system-ui, sans-serif; margin: 20px; }
    nav a { margin-right: 12px; text-decoration: none; color: #0366d6; }
    nav a:hover { text-decoration: underline; }
    img { border-radius: 4px; }
  </style>
</head>
<body>
<nav>
  <a href="/?page=modules/home.php">Home</a>
  <a href="/?page=modules/gallery.php">Gallery</a>
  <a href="/?page=modules/upload.php">Upload</a>
</nav>
<hr>
