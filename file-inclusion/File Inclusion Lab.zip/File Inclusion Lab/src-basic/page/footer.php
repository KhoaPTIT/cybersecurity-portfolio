<hr>
<footer>
  <small>Photo Board Lab — for educational purposes only.</small>
</footer>
</body>
</html>
