<?php
require __DIR__ . '/page/header.php';

$page = $_GET['page'] ?? 'home.php';
include __DIR__ . '/modules/' . $page;

require __DIR__ . '/page/footer.php';
