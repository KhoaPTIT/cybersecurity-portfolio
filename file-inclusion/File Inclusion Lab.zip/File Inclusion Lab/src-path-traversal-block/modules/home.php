<section style="max-width:760px">
  <h2 style="margin-bottom:8px">Photo Board</h2>
  <p>Chào mừng bạn đến với không gian nhỏ để chia sẻ khoảnh khắc thường ngày. Tại đây, bạn có thể lướt xem ảnh của mọi người trong <a href="/?page=gallery.php">Gallery</a> hoặc đăng tải bức hình bạn thích ở mục <a href="/?page=upload.php">Upload</a>.</p>

  <p>Trang được thiết kế thật nhẹ: không cần tài khoản, không cầu kỳ — chỉ cần chọn ảnh và đăng. Gallery sẽ hiển thị các bức mới nhất trước để bạn theo dõi dễ dàng.</p>

  <p>Một vài lưu ý khi đăng ảnh: hãy tôn trọng người khác, tránh nội dung phản cảm hoặc vi phạm bản quyền. Ảnh hỗ trợ các định dạng phổ biến như JPG, PNG và GIF.</p>

  <p style="margin-top:14px">Chúc bạn có những khoảnh khắc đẹp!</p>
</section>
