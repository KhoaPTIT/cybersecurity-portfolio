<?php
require __DIR__ . '/page/header.php';

$page = $_GET['page'] ?? 'home.php';
$page = str_replace('../', '', $page);
include __DIR__ . '/modules/' . $page;

require __DIR__ . '/page/footer.php';
