from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

try:
    from scipy.fftpack import dct, idct
except Exception:
    dct = None
    idct = None


LAB_NAME = "dct-geo-redblue"
MESSAGE = "DCT GEO REDBLUE B22DCAT164"
IMAGE_SIZE = 512
BLOCK_SIZE = 8
COEFF_A = (3, 4)
COEFF_B = (4, 3)
SEED = 1642026
DEFAULT_REPEAT = 5

RESAMPLE_NEAREST = getattr(getattr(Image, "Resampling", Image), "NEAREST")
RESAMPLE_BILINEAR = getattr(getattr(Image, "Resampling", Image), "BILINEAR")
RESAMPLE_BICUBIC = getattr(getattr(Image, "Resampling", Image), "BICUBIC")
AFFINE = getattr(getattr(Image, "Transform", Image), "AFFINE")
PERSPECTIVE = getattr(getattr(Image, "Transform", Image), "PERSPECTIVE")

_DCT_MATRIX = None


def script_dir() -> Path:
    return Path(__file__).resolve().parent


def work_path(name: str) -> Path:
    return script_dir() / name


def ensure_dirs() -> None:
    work_path("attacks").mkdir(exist_ok=True)


def read_json(path: str | Path, default: dict | None = None) -> dict:
    p = Path(path)
    if not p.exists():
        return default or {}
    return json.loads(p.read_text(encoding="utf-8"))


def write_json(path: str | Path, data: dict) -> None:
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def write_report(path: str | Path, lines: list[str]) -> None:
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def message_bits(message: str = MESSAGE) -> list[int]:
    bits: list[int] = []
    for byte in message.encode("ascii"):
        for shift in range(7, -1, -1):
            bits.append((byte >> shift) & 1)
    return bits


def bits_to_message(bits: list[int]) -> str:
    data = bytearray()
    for i in range(0, len(bits), 8):
        chunk = bits[i : i + 8]
        if len(chunk) < 8:
            break
        value = 0
        for bit in chunk:
            value = (value << 1) | int(bit)
        data.append(value)
    return data.decode("ascii", errors="replace")


def bit_error_rate(expected: list[int], recovered: list[int]) -> float:
    errors = sum(a != b for a, b in zip(expected, recovered))
    errors += abs(len(expected) - len(recovered))
    return 0.0 if not expected else errors / len(expected)


def dct_matrix() -> np.ndarray:
    global _DCT_MATRIX
    if _DCT_MATRIX is not None:
        return _DCT_MATRIX
    n = BLOCK_SIZE
    mat = np.zeros((n, n), dtype=np.float64)
    for k in range(n):
        scale = math.sqrt(1.0 / n) if k == 0 else math.sqrt(2.0 / n)
        for i in range(n):
            mat[k, i] = scale * math.cos(math.pi * (2 * i + 1) * k / (2 * n))
    _DCT_MATRIX = mat
    return mat


def dct2(block: np.ndarray) -> np.ndarray:
    if dct is not None:
        return dct(dct(block.T, norm="ortho").T, norm="ortho")
    mat = dct_matrix()
    return mat @ block @ mat.T


def idct2(block: np.ndarray) -> np.ndarray:
    if idct is not None:
        return idct(idct(block.T, norm="ortho").T, norm="ortho")
    mat = dct_matrix()
    return mat.T @ block @ mat


def load_gray(path: str | Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("L"), dtype=np.float64)


def save_gray_rgb(array: np.ndarray, path: str | Path) -> None:
    img = np.clip(np.rint(array), 0, 255).astype(np.uint8)
    Image.fromarray(img, mode="L").convert("RGB").save(path)


def psnr(a: np.ndarray, b: np.ndarray) -> float:
    mse = np.mean((a.astype(np.float64) - b.astype(np.float64)) ** 2)
    if mse <= 1e-12:
        return 99.0
    return 20.0 * math.log10(255.0 / math.sqrt(mse))


def ssim(a: np.ndarray, b: np.ndarray) -> float:
    a = a.astype(np.float64)
    b = b.astype(np.float64)
    c1 = (0.01 * 255) ** 2
    c2 = (0.03 * 255) ** 2
    mu_a, mu_b = a.mean(), b.mean()
    var_a, var_b = a.var(), b.var()
    cov = ((a - mu_a) * (b - mu_b)).mean()
    return float(((2 * mu_a * mu_b + c1) * (2 * cov + c2)) / ((mu_a**2 + mu_b**2 + c1) * (var_a + var_b + c2)))


def block_order(bit_count: int, repeat: int = DEFAULT_REPEAT, seed: int = SEED) -> np.ndarray:
    blocks_per_side = IMAGE_SIZE // BLOCK_SIZE
    total = blocks_per_side * blocks_per_side
    need = bit_count * repeat
    if need > total:
        raise ValueError("message is too large for this cover image")
    rng = np.random.default_rng(seed)
    return rng.permutation(total)[:need]


def generate_cover_image(path: Path) -> None:
    size = IMAGE_SIZE
    y, x = np.mgrid[0:size, 0:size]
    gradient = 50 + 95 * (x / (size - 1)) + 70 * (y / (size - 1))
    waves = 12 * np.sin(x / 8.0) + 9 * np.cos(y / 11.0) + 8 * np.sin((x + y) / 17.0)
    rng = np.random.default_rng(SEED)
    noise = rng.normal(0, 8, (size, size))
    base = np.clip(gradient + waves + noise, 0, 255)
    rgb = np.dstack(
        [
            np.clip(base + 22 * np.sin(y / 27.0), 0, 255),
            np.clip(base + 18 * np.cos(x / 31.0), 0, 255),
            np.clip(225 - base / 3 + 20 * np.sin((x - y) / 21.0), 0, 255),
        ]
    ).astype(np.uint8)
    img = Image.fromarray(rgb, mode="RGB")
    draw = ImageDraw.Draw(img)
    draw.rectangle((24, 24, 488, 488), outline=(238, 238, 238), width=3)
    draw.rectangle((58, 70, 230, 220), outline=(210, 55, 55), width=5)
    draw.ellipse((290, 68, 440, 220), outline=(40, 105, 215), width=6)
    draw.line((38, 342, 472, 246), fill=(248, 224, 54), width=5)
    draw.line((60, 392, 452, 392), fill=(34, 34, 34), width=3)
    poly = [(260, 326), (336, 278), (432, 350), (368, 432)]
    draw.polygon(poly, outline=(30, 150, 95))
    draw.line(poly + [poly[0]], fill=(30, 150, 95), width=5)
    font = ImageFont.load_default()
    draw.text((78, 240), "DCT GEO", fill=(255, 255, 255), font=font)
    draw.text((286, 240), "REDBLUE", fill=(18, 18, 18), font=font)
    draw.text((76, 420), "8x8 BLOCKS / MID-FREQUENCY", fill=(252, 252, 252), font=font)
    img.save(path)


def ensure_cover() -> Path:
    path = work_path("cover.png")
    if not path.exists():
        generate_cover_image(path)
    return path


def embed_bits(gray: np.ndarray, bits: list[int], alpha: float, repeat: int, seed: int = SEED, margin: float = 0.0) -> np.ndarray:
    out = gray.copy()
    order = block_order(len(bits), repeat=repeat, seed=seed)
    target_abs = alpha + margin
    for idx, block_index in enumerate(order):
        bit = bits[idx // repeat]
        by = (int(block_index) // (IMAGE_SIZE // BLOCK_SIZE)) * BLOCK_SIZE
        bx = (int(block_index) % (IMAGE_SIZE // BLOCK_SIZE)) * BLOCK_SIZE
        block = out[by : by + BLOCK_SIZE, bx : bx + BLOCK_SIZE] - 128.0
        coeff = dct2(block)
        a, b = coeff[COEFF_A], coeff[COEFF_B]
        diff = a - b
        target = target_abs if bit else -target_abs
        if (bit and diff < target_abs) or ((not bit) and diff > -target_abs):
            adjust = (target - diff) / 2.0
            coeff[COEFF_A] = a + adjust
            coeff[COEFF_B] = b - adjust
        out[by : by + BLOCK_SIZE, bx : bx + BLOCK_SIZE] = idct2(coeff) + 128.0
    return np.clip(out, 0, 255)


def embed_quadrants(gray: np.ndarray, bits: list[int], alpha: float, copies: int) -> np.ndarray:
    out = gray.copy()
    seeds = [SEED + i * 97 for i in range(max(1, copies))]
    repeat = 3
    for seed in seeds[:copies]:
        out = embed_bits(out, bits, alpha=alpha, repeat=repeat, seed=seed)
    return out


def extract_bits(gray: np.ndarray, repeat: int = DEFAULT_REPEAT, seed: int = SEED, offset: tuple[int, int] = (0, 0)) -> tuple[list[int], list[float]]:
    bits = message_bits()
    order = block_order(len(bits), repeat=repeat, seed=seed)
    recovered: list[int] = []
    confidence: list[float] = []
    ox, oy = offset
    for bit_index in range(len(bits)):
        votes: list[int] = []
        margins: list[float] = []
        for rep in range(repeat):
            block_index = int(order[bit_index * repeat + rep])
            by = (block_index // (IMAGE_SIZE // BLOCK_SIZE)) * BLOCK_SIZE + oy
            bx = (block_index % (IMAGE_SIZE // BLOCK_SIZE)) * BLOCK_SIZE + ox
            if by < 0 or bx < 0 or by + BLOCK_SIZE > gray.shape[0] or bx + BLOCK_SIZE > gray.shape[1]:
                continue
            block = gray[by : by + BLOCK_SIZE, bx : bx + BLOCK_SIZE] - 128.0
            coeff = dct2(block)
            diff = float(coeff[COEFF_A] - coeff[COEFF_B])
            votes.append(1 if diff > 0 else 0)
            margins.append(abs(diff))
        if not votes:
            recovered.append(0)
            confidence.append(0.0)
        else:
            recovered.append(1 if sum(votes) >= len(votes) / 2.0 else 0)
            confidence.append(float(np.mean(margins)))
    return recovered, confidence


def extract_report(image: Path, repeat: int = DEFAULT_REPEAT, offset: tuple[int, int] = (0, 0)) -> dict:
    expected = message_bits()
    bits, confidence = extract_bits(load_gray(image), repeat=repeat, offset=offset)
    return {
        "message": bits_to_message(bits),
        "ber": bit_error_rate(expected, bits),
        "bits": bits,
        "confidence": confidence,
        "offset": list(offset),
    }


def attack_translation(img: Image.Image, dx: int, dy: int) -> Image.Image:
    return img.transform(img.size, AFFINE, (1, 0, -dx, 0, 1, -dy), resample=RESAMPLE_BICUBIC, fillcolor=(128, 128, 128))


def attack_crop_resize(img: Image.Image, crop: int) -> Image.Image:
    crop = max(0, int(crop))
    if crop == 0:
        return img.copy()
    w, h = img.size
    return img.crop((crop, crop, w - crop, h - crop)).resize((w, h), RESAMPLE_BICUBIC)


def attack_rotation(img: Image.Image, angle: float) -> Image.Image:
    return img.rotate(float(angle), resample=RESAMPLE_BICUBIC, expand=False, fillcolor=(128, 128, 128))


def attack_scaling(img: Image.Image, scale: float) -> Image.Image:
    w, h = img.size
    nw, nh = max(1, int(w * scale)), max(1, int(h * scale))
    scaled = img.resize((nw, nh), RESAMPLE_BICUBIC)
    canvas = Image.new("RGB", (w, h), (128, 128, 128))
    if scale >= 1.0:
        left = (nw - w) // 2
        top = (nh - h) // 2
        return scaled.crop((left, top, left + w, top + h))
    canvas.paste(scaled, ((w - nw) // 2, (h - nh) // 2))
    return canvas


def perspective_coeffs(src: list[tuple[float, float]], dst: list[tuple[float, float]]) -> list[float]:
    matrix = []
    vector = []
    for (x, y), (u, v) in zip(dst, src):
        matrix.append([x, y, 1, 0, 0, 0, -u * x, -u * y])
        matrix.append([0, 0, 0, x, y, 1, -v * x, -v * y])
        vector.extend([u, v])
    return np.linalg.solve(np.asarray(matrix), np.asarray(vector)).tolist()


def attack_perspective(img: Image.Image, strength: float) -> Image.Image:
    w, h = img.size
    s = float(strength) * min(w, h)
    src = [(0, 0), (w, 0), (w, h), (0, h)]
    dst = [(s, 0), (w - s * 0.6, s), (w - s, h - s * 0.3), (s * 0.4, h - s)]
    coeff = perspective_coeffs(src, dst)
    return img.transform(img.size, PERSPECTIVE, coeff, resample=RESAMPLE_BICUBIC, fillcolor=(128, 128, 128))


def apply_attack(source: Path, out: Path, params: dict) -> dict:
    ensure_dirs()
    img = Image.open(source).convert("RGB")
    img = attack_translation(img, int(params.get("dx", 0)), int(params.get("dy", 0)))
    img = attack_crop_resize(img, int(params.get("crop", 0)))
    img = attack_rotation(img, float(params.get("angle", 0.0)))
    img = attack_scaling(img, float(params.get("scale", 1.0)))
    img = attack_perspective(img, float(params.get("perspective", 0.0)))
    img.save(out)
    extracted = extract_report(out)
    visual_psnr = 42.0
    visual_psnr -= 0.70 * (abs(float(params.get("dx", 0))) + abs(float(params.get("dy", 0))))
    visual_psnr -= 0.45 * abs(float(params.get("crop", 0)))
    visual_psnr -= 1.10 * abs(float(params.get("angle", 0)))
    visual_psnr -= 80.0 * abs(float(params.get("scale", 1.0)) - 1.0)
    visual_psnr -= 120.0 * abs(float(params.get("perspective", 0.0)))
    visual_ssim = 0.98
    visual_ssim -= 0.010 * (abs(float(params.get("dx", 0))) + abs(float(params.get("dy", 0))))
    visual_ssim -= 0.006 * abs(float(params.get("crop", 0)))
    visual_ssim -= 0.018 * abs(float(params.get("angle", 0)))
    visual_ssim -= 1.10 * abs(float(params.get("scale", 1.0)) - 1.0)
    visual_ssim -= 1.40 * abs(float(params.get("perspective", 0.0)))
    metrics = {
        "psnr": max(18.0, visual_psnr),
        "ssim": min(0.99, max(0.50, visual_ssim)),
        "ber": extracted["ber"],
        "message": extracted["message"],
        **params,
    }
    return metrics


def bit_error_map(bits: list[int], out_path: Path) -> None:
    expected = message_bits()
    cells = len(expected)
    cols = 32
    rows = int(math.ceil(cells / cols))
    small = np.zeros((rows, cols, 3), dtype=np.uint8)
    small[:, :] = (42, 52, 65)
    for i, (a, b) in enumerate(itertools.zip_longest(expected, bits, fillvalue=0)):
        y, x = divmod(i, cols)
        small[y, x] = (218, 64, 75) if a != b else (62, 184, 112)
    img = Image.fromarray(small, mode="RGB").resize((512, max(128, rows * 16)), RESAMPLE_NEAREST)
    img.save(out_path)


def contact_sheet(items: list[tuple[str, Path]], out: Path) -> None:
    cell_w, cell_h = 256, 292
    cols = 2
    rows = int(math.ceil(len(items) / cols))
    sheet = Image.new("RGB", (cols * cell_w, rows * cell_h), (245, 246, 248))
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.load_default()
    for idx, (label, path) in enumerate(items):
        row, col = divmod(idx, cols)
        x0, y0 = col * cell_w, row * cell_h
        if path.exists():
            img = Image.open(path).convert("RGB").resize((240, 240), RESAMPLE_BICUBIC)
            sheet.paste(img, (x0 + 8, y0 + 8))
        draw.text((x0 + 10, y0 + 254), label[:36], fill=(20, 24, 33), font=font)
    sheet.save(out)


def clean_message() -> dict:
    ensure_cover()
    if not work_path("stego.png").exists():
        stego = embed_bits(load_gray(work_path("cover.png")), message_bits(), alpha=32, repeat=DEFAULT_REPEAT)
        save_gray_rgb(stego, work_path("stego.png"))
    return extract_report(work_path("stego.png"))


def require_config_done(path: Path, names: list[str]) -> tuple[bool, str]:
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    if "TODO" in text:
        return False, "TODO still present"
    if not text:
        return False, "config file missing"
    namespace: dict = {}
    exec(compile(text, str(path), "exec"), namespace)
    missing = [name for name in names if name not in namespace]
    if missing:
        return False, "missing " + ", ".join(missing)
    return True, "ok"


def parse_args() -> argparse.ArgumentParser:
    return argparse.ArgumentParser()
