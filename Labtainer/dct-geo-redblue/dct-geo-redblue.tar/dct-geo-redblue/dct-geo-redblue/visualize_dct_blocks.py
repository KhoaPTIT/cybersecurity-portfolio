import numpy as np
from PIL import Image, ImageDraw

from redblue_helper import BLOCK_SIZE, COEFF_A, COEFF_B, RESAMPLE_NEAREST, dct2, ensure_cover, load_gray, work_path, write_report

gray = load_gray(ensure_cover())
img = Image.open(work_path("cover.png")).convert("RGB")
draw = ImageDraw.Draw(img)
for pos in range(0, img.size[0], BLOCK_SIZE):
    color = (255, 255, 255) if pos % 64 == 0 else (80, 80, 80)
    draw.line((pos, 0, pos, img.size[1]), fill=color)
    draw.line((0, pos, img.size[0], pos), fill=color)
img.save(work_path("dct_block_grid.png"))

spectrum = np.zeros((8, 8), dtype=np.float64)
count = 0
for y in range(0, gray.shape[0], 8):
    for x in range(0, gray.shape[1], 8):
        spectrum += np.abs(dct2(gray[y : y + 8, x : x + 8] - 128.0))
        count += 1
spectrum = np.log1p(spectrum / max(1, count))
spectrum = (255 * (spectrum - spectrum.min()) / (np.ptp(spectrum) + 1e-9)).astype(np.uint8)
rgb = np.dstack([spectrum, spectrum, spectrum])
rgb[COEFF_A] = (230, 72, 84)
rgb[COEFF_B] = (45, 126, 230)
Image.fromarray(rgb, mode="RGB").resize((512, 512), RESAMPLE_NEAREST).save(work_path("dct_spectrum.png"))
write_report(
    work_path("dct_visual_report.txt"),
    [
        "DCT block visualization completed",
        "dct_block_grid.png shows the original 8x8 extractor grid.",
        "dct_spectrum.png highlights the two mid-frequency coefficients used for bits.",
    ],
)
