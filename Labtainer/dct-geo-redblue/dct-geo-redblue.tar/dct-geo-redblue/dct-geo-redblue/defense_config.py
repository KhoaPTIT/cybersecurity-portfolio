OFFSET_RADIUS = 0
VOTE_MODE = "none"
MIN_CONFIDENCE = 0.0
USE_QUADRANT_VOTING = False
USE_CHECKSUM = False

# TODO: tune defense parameters
