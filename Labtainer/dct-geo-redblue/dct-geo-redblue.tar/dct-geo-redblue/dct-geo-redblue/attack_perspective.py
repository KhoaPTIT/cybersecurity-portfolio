import argparse

from redblue_helper import apply_attack, work_path, write_report

parser = argparse.ArgumentParser()
parser.add_argument("--strength", type=float, default=0.035)
args = parser.parse_args()
metrics = apply_attack(work_path("stego.png"), work_path("attacks/perspective_attack.png"), {"dx": 0, "dy": 0, "crop": 0, "angle": 0, "scale": 1.0, "perspective": args.strength})
write_report(work_path("perspective_report.txt"), ["Perspective attack completed", f"strength={args.strength}", f"BER: {metrics['ber'] * 100:.2f}%", f"PSNR: {metrics['psnr']:.2f} dB", f"SSIM: {metrics['ssim']:.3f}"])
