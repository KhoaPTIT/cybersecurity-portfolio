import argparse
import importlib

import numpy as np
from PIL import Image

from redblue_helper import RESAMPLE_NEAREST, bit_error_rate, bits_to_message, extract_bits, load_gray, message_bits, require_config_done, work_path, write_json, write_report

parser = argparse.ArgumentParser()
parser.add_argument("--image", default="attacks/optimized_attack.png")
args = parser.parse_args()

ok, reason = require_config_done(work_path("defense_config.py"), ["OFFSET_RADIUS", "VOTE_MODE", "MIN_CONFIDENCE", "USE_QUADRANT_VOTING", "USE_CHECKSUM"])
if not ok:
    write_report(work_path("offset_voting_report.txt"), ["Offset voting defense failed", reason])
    raise SystemExit(1)

cfg = importlib.import_module("defense_config")
if cfg.OFFSET_RADIUS < 4 or not cfg.USE_QUADRANT_VOTING:
    write_report(work_path("offset_voting_report.txt"), ["Offset voting defense failed", "Set OFFSET_RADIUS >= 4 and USE_QUADRANT_VOTING = True"])
    raise SystemExit(1)

gray = load_gray(work_path(args.image))
expected = message_bits()
best = None
heat = np.zeros((2 * cfg.OFFSET_RADIUS + 1, 2 * cfg.OFFSET_RADIUS + 1), dtype=np.float64)
for oy in range(-cfg.OFFSET_RADIUS, cfg.OFFSET_RADIUS + 1):
    for ox in range(-cfg.OFFSET_RADIUS, cfg.OFFSET_RADIUS + 1):
        bits, confidence = extract_bits(gray, offset=(ox, oy))
        ber = bit_error_rate(expected, bits)
        heat[oy + cfg.OFFSET_RADIUS, ox + cfg.OFFSET_RADIUS] = 1.0 - ber
        item = {"offset": [ox, oy], "ber": ber, "message": bits_to_message(bits), "confidence": float(np.mean(confidence)), "bits": bits}
        if best is None or item["ber"] < best["ber"]:
            best = item

scaled = (255 * (heat - heat.min()) / (np.ptp(heat) + 1e-9)).astype(np.uint8)
rgb = np.dstack([255 - scaled, scaled, np.zeros_like(scaled)])
Image.fromarray(rgb, mode="RGB").resize((512, 512), RESAMPLE_NEAREST).save(work_path("offset_vote_map.png"))
write_json(work_path("offset_voting_metrics.json"), best)
passed = best["ber"] <= 0.18
write_report(
    work_path("offset_voting_report.txt"),
    [
        "Offset voting defense passed" if passed else "Offset voting defense failed",
        f"Best offset: {best['offset']}",
        f"BER after offset voting: {best['ber'] * 100:.2f}%",
        f"Confidence: {best['confidence']:.2f}",
        f"Recovered: {best['message']}",
    ],
)
if not passed:
    raise SystemExit(1)
