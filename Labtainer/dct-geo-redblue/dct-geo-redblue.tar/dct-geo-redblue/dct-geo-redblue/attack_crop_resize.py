import argparse

from redblue_helper import apply_attack, work_path, write_report

parser = argparse.ArgumentParser()
parser.add_argument("--crop", type=int, default=12)
args = parser.parse_args()
metrics = apply_attack(work_path("stego.png"), work_path("attacks/crop_resize_attack.png"), {"dx": 0, "dy": 0, "crop": args.crop, "angle": 0, "scale": 1.0, "perspective": 0.0})
write_report(work_path("crop_resize_report.txt"), ["Crop resize attack completed", f"crop={args.crop}", f"BER: {metrics['ber'] * 100:.2f}%", f"PSNR: {metrics['psnr']:.2f} dB", f"SSIM: {metrics['ssim']:.3f}"])
