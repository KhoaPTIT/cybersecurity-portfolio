# Defense Memo

TODO: replace this template with measured raw BER and final BER analysis.
