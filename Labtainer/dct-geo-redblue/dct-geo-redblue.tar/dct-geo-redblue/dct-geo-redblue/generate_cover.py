from redblue_helper import generate_cover_image, work_path, write_report

generate_cover_image(work_path("cover.png"))
write_report(
    work_path("cover_report.txt"),
    [
        "Cover image generated",
        "Image: cover.png",
        "Observation: smooth, edge, and texture regions are present.",
        "Texture regions are better DCT embedding candidates than flat regions.",
    ],
)
