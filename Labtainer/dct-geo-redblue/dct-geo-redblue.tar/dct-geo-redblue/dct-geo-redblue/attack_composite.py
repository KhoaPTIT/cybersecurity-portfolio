import argparse

from redblue_helper import apply_attack, work_path, write_report

parser = argparse.ArgumentParser()
parser.add_argument("--dx", type=int, default=4)
parser.add_argument("--dy", type=int, default=-3)
parser.add_argument("--crop", type=int, default=8)
parser.add_argument("--angle", type=float, default=3.0)
parser.add_argument("--scale", type=float, default=0.95)
args = parser.parse_args()
params = {"dx": args.dx, "dy": args.dy, "crop": args.crop, "angle": args.angle, "scale": args.scale, "perspective": 0.0}
metrics = apply_attack(work_path("stego.png"), work_path("attacks/composite_attack.png"), params)
write_report(work_path("composite_report.txt"), ["Composite geometric attack completed", f"params={params}", f"BER: {metrics['ber'] * 100:.2f}%", f"PSNR: {metrics['psnr']:.2f} dB", f"SSIM: {metrics['ssim']:.3f}"])
