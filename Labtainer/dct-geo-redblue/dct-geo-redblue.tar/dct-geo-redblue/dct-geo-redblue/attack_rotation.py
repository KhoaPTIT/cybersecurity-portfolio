import argparse

from redblue_helper import apply_attack, work_path, write_report

parser = argparse.ArgumentParser()
parser.add_argument("--angle", type=float, default=4.0)
args = parser.parse_args()
metrics = apply_attack(work_path("stego.png"), work_path("attacks/rotation_attack.png"), {"dx": 0, "dy": 0, "crop": 0, "angle": args.angle, "scale": 1.0, "perspective": 0.0})
write_report(work_path("rotation_report.txt"), ["Rotation attack completed", f"angle={args.angle}", f"BER: {metrics['ber'] * 100:.2f}%", f"PSNR: {metrics['psnr']:.2f} dB", f"SSIM: {metrics['ssim']:.3f}"])
