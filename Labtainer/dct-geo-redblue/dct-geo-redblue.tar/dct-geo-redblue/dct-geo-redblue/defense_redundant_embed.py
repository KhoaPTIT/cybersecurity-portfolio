import argparse

from redblue_helper import embed_quadrants, load_gray, message_bits, psnr, save_gray_rgb, work_path, write_json, write_report

parser = argparse.ArgumentParser()
parser.add_argument("--copies", type=int, default=4)
parser.add_argument("--alpha", type=float, default=36.0)
args = parser.parse_args()

cover = load_gray(work_path("cover.png"))
defended = embed_quadrants(cover, message_bits(), alpha=args.alpha, copies=args.copies)
save_gray_rgb(defended, work_path("defended_stego.png"))
metrics = {"copies": args.copies, "alpha": args.alpha, "psnr": psnr(cover, defended)}
write_json(work_path("redundant_metrics.json"), metrics)
write_report(
    work_path("redundant_defense_report.txt"),
    [
        "Redundant quadrant embedding completed",
        f"Copies: {args.copies}",
        f"Alpha: {args.alpha}",
        f"Defense PSNR: {metrics['psnr']:.2f} dB",
    ],
)
