import argparse

from redblue_helper import apply_attack, work_path, write_report

parser = argparse.ArgumentParser()
parser.add_argument("--scale", type=float, default=0.92)
args = parser.parse_args()
metrics = apply_attack(work_path("stego.png"), work_path("attacks/scaling_attack.png"), {"dx": 0, "dy": 0, "crop": 0, "angle": 0, "scale": args.scale, "perspective": 0.0})
write_report(work_path("scaling_report.txt"), ["Scaling attack completed", "Rotation and scaling attacks completed", f"scale={args.scale}", f"BER: {metrics['ber'] * 100:.2f}%", f"PSNR: {metrics['psnr']:.2f} dB", f"SSIM: {metrics['ssim']:.3f}"])
