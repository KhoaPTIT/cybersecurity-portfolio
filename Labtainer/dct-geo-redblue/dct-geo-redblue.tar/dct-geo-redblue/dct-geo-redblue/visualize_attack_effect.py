from redblue_helper import contact_sheet, work_path, write_report

contact_sheet(
    [
        ("cover.png", work_path("cover.png")),
        ("stego.png", work_path("stego.png")),
        ("optimized_attack.png", work_path("attacks/optimized_attack.png")),
        ("raw_bit_error_map.png", work_path("raw_bit_error_map.png")),
    ],
    work_path("attack_contact_sheet.png"),
)
write_report(work_path("attack_visual_report.txt"), ["Attack visualization completed", "attack_contact_sheet.png created"])
