from redblue_helper import contact_sheet, work_path, write_report

contact_sheet(
    [
        ("defended_stego.png", work_path("defended_stego.png")),
        ("offset_vote_map.png", work_path("offset_vote_map.png")),
        ("checksum_recovery_map.png", work_path("checksum_recovery_map.png")),
        ("optimized_attack.png", work_path("attacks/optimized_attack.png")),
    ],
    work_path("defense_contact_sheet.png"),
)
write_report(work_path("defense_visual_report.txt"), ["Attack and defense visualization completed", "defense_contact_sheet.png created"])
