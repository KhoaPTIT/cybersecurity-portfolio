import argparse

from redblue_helper import DEFAULT_REPEAT, clean_message, embed_bits, load_gray, message_bits, psnr, save_gray_rgb, work_path, write_json, write_report

parser = argparse.ArgumentParser()
parser.add_argument("--alpha", type=float, default=32.0)
parser.add_argument("--repeat", type=int, default=DEFAULT_REPEAT)
args = parser.parse_args()

cover = work_path("cover.png")
if not cover.exists():
    import generate_cover  # noqa: F401

cover_gray = load_gray(cover)
stego = embed_bits(cover_gray, message_bits(), alpha=args.alpha, repeat=args.repeat)
save_gray_rgb(stego, work_path("stego.png"))
clean = clean_message()
metrics = {"alpha": args.alpha, "repeat": args.repeat, "psnr": psnr(cover_gray, stego), "clean_ber": clean["ber"], "message": clean["message"]}
write_json(work_path("embed_metrics.json"), metrics)
status = "DCT message embedded" if metrics["psnr"] >= 35.0 and metrics["clean_ber"] <= 0.02 else "DCT message embedded but thresholds not met"
write_report(
    work_path("embed_report.txt"),
    [
        status,
        "Message: DCT GEO REDBLUE B22DCAT164",
        f"PSNR: {metrics['psnr']:.2f} dB",
        f"Clean BER: {metrics['clean_ber'] * 100:.2f}%",
        f"Recovered: {metrics['message']}",
    ],
)
