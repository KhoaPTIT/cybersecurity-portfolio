from pathlib import Path

from redblue_helper import read_json, work_path, write_report

required_images = [
    "cover.png",
    "stego.png",
    "dct_block_grid.png",
    "dct_spectrum.png",
    "attacks/translation_attack.png",
    "attacks/crop_resize_attack.png",
    "attacks/rotation_attack.png",
    "attacks/scaling_attack.png",
    "attacks/perspective_attack.png",
    "attacks/composite_attack.png",
    "attacks/optimized_attack.png",
    "raw_bit_error_map.png",
    "attack_contact_sheet.png",
    "defended_stego.png",
    "offset_vote_map.png",
    "checksum_recovery_map.png",
    "defense_contact_sheet.png",
]
missing = [name for name in required_images if not work_path(name).exists()]
attack = read_json(work_path("optimized_attack_metrics.json"), {})
checksum = read_json(work_path("checksum_recovery_metrics.json"), {})
ok = not missing and attack.get("ber", 0) >= 0.35 and checksum.get("final_ber", 1) <= 0.12
write_report(
    work_path("summary_report.txt"),
    [
        "RedBlue DCT geometric lab summary completed" if ok else "RedBlue DCT geometric lab summary incomplete",
        f"Optimized BER: {attack.get('ber', 0) * 100:.2f}%",
        f"Final BER: {checksum.get('final_ber', 1) * 100:.2f}%",
        "Missing images: " + (", ".join(missing) if missing else "none"),
    ],
)
if not ok:
    raise SystemExit(1)
