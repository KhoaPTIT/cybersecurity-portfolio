import argparse

from redblue_helper import apply_attack, work_path, write_report

parser = argparse.ArgumentParser()
parser.add_argument("--dx", type=int, default=3)
parser.add_argument("--dy", type=int, default=5)
args = parser.parse_args()
metrics = apply_attack(work_path("stego.png"), work_path("attacks/translation_attack.png"), {"dx": args.dx, "dy": args.dy, "crop": 0, "angle": 0, "scale": 1.0, "perspective": 0.0})
write_report(work_path("translation_report.txt"), ["Translation attack completed", f"dx={args.dx} dy={args.dy}", f"BER: {metrics['ber'] * 100:.2f}%", f"PSNR: {metrics['psnr']:.2f} dB", f"SSIM: {metrics['ssim']:.3f}"])
