import argparse

from redblue_helper import extract_report, work_path, write_report

parser = argparse.ArgumentParser()
parser.add_argument("--image", default="stego.png")
args = parser.parse_args()

result = extract_report(work_path(args.image))
write_report(
    work_path("extract_report.txt"),
    [
        "DCT message extracted",
        f"Image: {args.image}",
        f"Recovered: {result['message']}",
        f"BER: {result['ber'] * 100:.2f}%",
    ],
)
print(result["message"])
