# DCT Geo RedBlue

Geometric Attack and Defense on DCT Image Steganography.

Embedded message:

```text
DCT GEO REDBLUE B22DCAT164
```

Run the tasks in order. Use `eog` to inspect generated images and `cat *_report.txt` to inspect metrics.

## Required edits

You must edit these files before the related validation tasks pass:

```text
attack_config.py
defense_config.py
ATTACK_MEMO.md
DEFENSE_MEMO.md
```

Remove the `TODO` lines after completing your analysis.

## Quick task list

```bash
python3 generate_cover.py
python3 embed_dct_message.py --alpha 32 --repeat 5
python3 visualize_dct_blocks.py
python3 attack_translation.py --dx 3 --dy 5
python3 attack_crop_resize.py --crop 12
python3 attack_rotation.py --angle 4
python3 attack_scaling.py --scale 0.92
python3 attack_perspective.py --strength 0.035
python3 attack_composite.py --dx 4 --dy -3 --crop 8 --angle 3 --scale 0.95
```

Tune `attack_config.py`, then run:

```bash
python3 attack_optimizer.py
python3 validate_attack_memo.py
```

Run Blue Team defenses:

```bash
python3 defense_margin_hardening.py --alpha 40 --margin 18
python3 defense_redundant_embed.py --copies 4 --alpha 36
```

Tune `defense_config.py`, then run:

```bash
python3 defense_offset_voting.py --image attacks/optimized_attack.png
python3 defense_checksum_recovery.py --image attacks/optimized_attack.png
python3 visualize_attack_effect.py
python3 visualize_defense_effect.py
python3 validate_defense_memo.py
python3 summary.py
checkwork
```

Expected checkwork labname:

```text
dct-geo-redblue
```
