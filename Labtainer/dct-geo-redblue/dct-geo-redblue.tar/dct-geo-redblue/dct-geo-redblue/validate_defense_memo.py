from pathlib import Path

from redblue_helper import read_json, work_path, write_report

memo = Path(work_path("DEFENSE_MEMO.md")).read_text(encoding="utf-8") if work_path("DEFENSE_MEMO.md").exists() else ""
checksum = read_json(work_path("checksum_recovery_metrics.json"), {})
required = ["raw", "margin", "redundant", "offset", "checksum", "remaining", "ber"]
missing = [word for word in required if word not in memo.lower()]
has_numbers = any(ch.isdigit() for ch in memo)
ok = "TODO" not in memo and not missing and has_numbers and checksum.get("final_ber", 1) <= 0.12
write_report(
    work_path("defense_memo_report.txt"),
    [
        "Defense memo accepted" if ok else "Defense memo rejected",
        "Missing keywords: " + ", ".join(missing) if missing else "Required defense concepts found.",
        f"Final BER available: {checksum.get('final_ber', 1) * 100:.2f}%",
    ],
)
if not ok:
    raise SystemExit(1)
