from pathlib import Path

from redblue_helper import read_json, work_path, write_report

memo = Path(work_path("ATTACK_MEMO.md")).read_text(encoding="utf-8") if work_path("ATTACK_MEMO.md").exists() else ""
metrics = read_json(work_path("optimized_attack_metrics.json"), {})
required = ["strongest", "visual", "dct", "block", "ber", "psnr", "ssim", "trade"]
missing = [word for word in required if word not in memo.lower()]
has_numbers = any(ch.isdigit() for ch in memo)
ok = "TODO" not in memo and not missing and has_numbers and metrics.get("ber", 0) >= 0.35
write_report(
    work_path("attack_memo_report.txt"),
    [
        "Attack memo accepted" if ok else "Attack memo rejected",
        "Missing keywords: " + ", ".join(missing) if missing else "Required attack concepts found.",
        f"Optimized BER available: {metrics.get('ber', 0) * 100:.2f}%",
    ],
)
if not ok:
    raise SystemExit(1)
