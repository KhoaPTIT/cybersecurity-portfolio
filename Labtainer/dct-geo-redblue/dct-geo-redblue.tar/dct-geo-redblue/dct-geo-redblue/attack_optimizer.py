import importlib

from redblue_helper import apply_attack, bit_error_map, extract_report, require_config_done, work_path, write_json, write_report

ok, reason = require_config_done(
    work_path("attack_config.py"),
    ["MAX_ROTATION", "MAX_CROP", "MAX_TRANSLATION", "MIN_SCALE", "MAX_SCALE", "MAX_PERSPECTIVE", "MIN_PSNR", "MIN_SSIM", "TARGET_BER"],
)
if not ok:
    write_report(work_path("optimized_attack_report.txt"), ["Red team optimized attack failed", reason])
    raise SystemExit(1)

cfg = importlib.import_module("attack_config")
best = None
best_params = None
translations = sorted(set([0, min(3, cfg.MAX_TRANSLATION), min(4, cfg.MAX_TRANSLATION), cfg.MAX_TRANSLATION, -min(4, cfg.MAX_TRANSLATION)]))
crops = sorted(set([0, min(8, cfg.MAX_CROP), cfg.MAX_CROP]))
angles = sorted(set([0.0, min(2.0, float(cfg.MAX_ROTATION)), min(4.0, float(cfg.MAX_ROTATION))]))
scales = sorted(set([1.0, max(float(cfg.MIN_SCALE), 0.96), min(float(cfg.MAX_SCALE), 1.02)]))
perspectives = sorted(set([0.0, min(0.02, float(cfg.MAX_PERSPECTIVE))]))

for dx in translations:
    for dy in translations:
        params = {"dx": int(dx), "dy": int(dy), "crop": 0, "angle": 0.0, "scale": 1.0, "perspective": 0.0}
        metrics = apply_attack(work_path("stego.png"), work_path("attacks/optimized_attack.png"), params)
        if metrics["psnr"] < cfg.MIN_PSNR or metrics["ssim"] < cfg.MIN_SSIM:
            continue
        if best is None or metrics["ber"] > best["ber"]:
            best = metrics
            best_params = params

if best is not None and best["ber"] * 100.0 >= max(35.0, cfg.TARGET_BER):
    crops = []
    angles = []
    scales = []
    perspectives = []

for dx in translations:
    for dy in translations:
        for crop in crops:
            for angle in angles:
                for scale in scales:
                    for perspective in perspectives:
                        params = {"dx": int(dx), "dy": int(dy), "crop": int(crop), "angle": float(angle), "scale": float(scale), "perspective": float(perspective)}
                        metrics = apply_attack(work_path("stego.png"), work_path("attacks/optimized_attack.png"), params)
                        if metrics["psnr"] < cfg.MIN_PSNR or metrics["ssim"] < cfg.MIN_SSIM:
                            continue
                        if best is None or metrics["ber"] > best["ber"]:
                            best = metrics
                            best_params = params

if best is None:
    best_params = {"dx": min(4, cfg.MAX_TRANSLATION), "dy": min(4, cfg.MAX_TRANSLATION), "crop": 0, "angle": 0, "scale": 1.0, "perspective": 0.0}

best = apply_attack(work_path("stego.png"), work_path("attacks/optimized_attack.png"), best_params)
extracted = extract_report(work_path("attacks/optimized_attack.png"))
bit_error_map(extracted["bits"], work_path("raw_bit_error_map.png"))
write_json(work_path("optimized_attack_metrics.json"), best)
write_json(work_path("optimized_attack_params.json"), best_params)
passed = best["ber"] * 100.0 >= max(35.0, cfg.TARGET_BER) and best["psnr"] >= cfg.MIN_PSNR and best["ssim"] >= cfg.MIN_SSIM
write_report(
    work_path("optimized_attack_report.txt"),
    [
        "Red team optimized attack passed" if passed else "Red team optimized attack failed",
        f"Best params: {best_params}",
        f"Optimized BER: {best['ber'] * 100:.2f}%",
        f"PSNR: {best['psnr']:.2f} dB",
        f"SSIM: {best['ssim']:.3f}",
        f"Recovered: {best['message']}",
    ],
)
if not passed:
    raise SystemExit(1)
