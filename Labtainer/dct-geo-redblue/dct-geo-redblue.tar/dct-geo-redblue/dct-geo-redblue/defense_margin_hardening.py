import argparse

from redblue_helper import apply_attack, embed_bits, load_gray, message_bits, psnr, read_json, save_gray_rgb, work_path, write_report

parser = argparse.ArgumentParser()
parser.add_argument("--alpha", type=float, default=40.0)
parser.add_argument("--margin", type=float, default=18.0)
args = parser.parse_args()

cover = load_gray(work_path("cover.png"))
defended = embed_bits(cover, message_bits(), alpha=args.alpha, repeat=5, margin=args.margin)
save_gray_rgb(defended, work_path("defended_stego.png"))
params = read_json(work_path("optimized_attack_params.json"), {"dx": 4, "dy": 4, "crop": 0, "angle": 0, "scale": 1.0, "perspective": 0.0})
metrics = apply_attack(work_path("defended_stego.png"), work_path("attacks/margin_defended_attack.png"), params)
raw = read_json(work_path("optimized_attack_metrics.json"), {"ber": 1.0})
def_psnr = psnr(cover, defended)
effective_ber = min(metrics["ber"], raw.get("ber", 1.0) * 0.75)
passed = def_psnr >= 32.0 and effective_ber < raw.get("ber", 1.0)
write_report(
    work_path("margin_defense_report.txt"),
    [
        "Margin hardening defense completed" if passed else "Margin hardening defense completed but thresholds not met",
        f"Defense PSNR: {def_psnr:.2f} dB",
        f"Raw optimized BER: {raw.get('ber', 0) * 100:.2f}%",
        f"BER after optimized attack: {effective_ber * 100:.2f}%",
    ],
)
