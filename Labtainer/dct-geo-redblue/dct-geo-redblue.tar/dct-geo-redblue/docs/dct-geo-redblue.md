# DCT Geo RedBlue

This Labtainer lab asks students to attack and defend DCT block image steganography under small geometric transformations. Red Team creates attacks that raise BER while preserving visual quality. Blue Team combines stronger DCT margins, redundant quadrant embedding, offset voting, and checksum recovery.

The lab intentionally starts with weak `attack_config.py` and `defense_config.py` files and memo templates containing `TODO`. Checkwork requires students to tune the configs, generate visual evidence, and write measured analysis.
