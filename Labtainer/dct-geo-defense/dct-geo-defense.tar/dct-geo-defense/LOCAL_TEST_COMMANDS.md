# LOCAL_TEST_COMMANDS

Quy trinh local-first cho nguoi tao lab. Khong push GitHub hoac DockerHub trong buoc nay.

## Buoc 1: Kiem tra source lab

```bash
cd ~/labtainer/trunk/labs/dct-geo-defense
```

## Buoc 2: Kiem tra syntax Python

```bash
python3 -m py_compile *.py
```

## Buoc 3: Chay selftest logic Python cho instructor

```bash
DCT_DEFENSE_SELFTEST_SOLUTION=1 python3 selftest_local.py
```

## Buoc 4: Rebuild va chay lab local

```bash
cd ~/labtainer/trunk/scripts/labtainer-student
labtainer -r dct-geo-defense
```

## Buoc 5: Trong terminal container, chay lan luot

```bash
python3 calibrate_dct_defense.py --alpha 35 --repeat 5
python3 parameter_sweep.py --alphas 25,35,45 --repeats 5,7
python3 build_geometric_benchmark.py
python3 validate_defense_plan.py
python3 apply_plan_to_config.py

# Sua DEFENSE_PLAN.md / defense_config.py truoc buoc nay.
python3 registration_defense.py
python3 visualize_defense.py
python3 validate_defense_memo.py
python3 summary.py
```

## Buoc 6: Checkwork

```bash
checkwork
```

## Buoc 7: Dung lab

```bash
stoplab dct-geo-defense
```
