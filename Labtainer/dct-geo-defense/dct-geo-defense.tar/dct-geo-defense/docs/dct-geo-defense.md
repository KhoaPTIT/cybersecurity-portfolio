# dct-geo-defense

Hoc phan: Ky thuat giau tin  
Muc do: Kho  
Chu de: Phong thu giau tin anh DCT truoc tan cong hinh hoc

## Mo ta

Lab nay bat sinh vien lam dung vai tro thiet ke phong thu. Workflow khong phai la chay tung lenh tan cong, ma gom nhieu dang task:

1. Hieu chinh DCT embedding va quan sat anh.
2. Sweep tham so `ALPHA`/`REPEAT_N` de thay trade-off PSNR/BER.
3. Sinh benchmark hinh hoc tong hop de xac dinh rui ro.
4. Viet `DEFENSE_PLAN.md` co tham so, bang chung va ly do.
5. Sinh/sua `defense_config.py` tu plan.
6. Chay tai dong bo hinh hoc va giam BER.
7. Tao evidence board truc quan.
8. Viet `DEFENSE_MEMO.md` va validate.
9. Summary va checkwork.

## Checkwork

Checkwork kiem tra cac marker sau:

- `sweep_report.txt`: `Parameter sweep completed`
- `benchmark_report.txt`: `Geometric defense benchmark completed`
- `plan_report.txt`: `Defense plan accepted`
- `config_report.txt`: `Defense config generated from plan`
- `defense_report.txt`: `Geometric resynchronization defense PASSED`
- `visual_defense_report.txt`: `Defense visual comparison completed`
- `memo_report.txt`: `Defense memo accepted`
- `summary_report.txt`: `Summary Completed`

`DEFENSE_PLAN.md` va `DEFENSE_MEMO.md` co placeholder `TODO`; sinh vien phai sua that, khong the pass bang cach chay lenh mac dinh.
