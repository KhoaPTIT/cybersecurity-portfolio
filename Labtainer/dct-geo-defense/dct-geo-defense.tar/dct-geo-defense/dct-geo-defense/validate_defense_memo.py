from __future__ import annotations

from dct_helper import work_path, write_report


MEMO = work_path("DEFENSE_MEMO.md")


def section_text(text: str, heading: str) -> str:
    marker = f"## {heading}"
    start = text.find(marker)
    if start < 0:
        return ""
    start += len(marker)
    next_heading = text.find("\n## ", start)
    return text[start:] if next_heading < 0 else text[start:next_heading]


def main() -> int:
    text = MEMO.read_text(encoding="utf-8") if MEMO.exists() else ""
    errors: list[str] = []
    if "TODO" in text or "..." in text:
        errors.append("remove TODO/... placeholders")
    if len(text) < 750:
        errors.append("memo is too short")
    for heading in ["Visual Evidence", "Quantitative Evidence", "What I Changed", "Residual Risk"]:
        body = section_text(text, heading).strip()
        if len(body) < 90:
            errors.append(f"section '{heading}' needs more detail")
    if "Defense BER" not in (work_path("defense_report.txt").read_text(encoding="utf-8") if work_path("defense_report.txt").exists() else ""):
        errors.append("run registration_defense.py before validating memo")
    if not work_path("defense_contact_sheet.png").exists():
        errors.append("run visualize_defense.py before validating memo")

    passed = not errors
    lines = ["Defense memo accepted" if passed else "Defense memo rejected"]
    lines.extend(errors or ["Memo cites visual evidence, BER/PSNR, config changes, and residual risk."])
    write_report(work_path("memo_report.txt"), lines)
    for line in lines:
        print(line)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
