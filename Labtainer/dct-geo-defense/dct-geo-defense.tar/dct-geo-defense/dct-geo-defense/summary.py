from __future__ import annotations

import re

from dct_helper import read_json, work_path, write_report


def read_text(name: str) -> str:
    path = work_path(name)
    return path.read_text(encoding="utf-8") if path.exists() else ""


def first_ber_percent(text: str) -> str:
    match = re.search(r"BER(?:\s*=|\s*:)?\s*([0-9.]+)%", text)
    if match:
        return f"{float(match.group(1)):.2f}%"
    match = re.search(r",([0-9.]+),", text)
    if match:
        return f"{float(match.group(1)):.2f}%"
    return "n/a"


def main() -> None:
    embed = read_json(work_path("embed_metrics.json"), {})
    defense = read_json(work_path("defense_metrics.json"), {})
    lines = [
        "Summary Completed",
        f"PSNR: {float(embed.get('psnr', 0.0)):.2f} dB",
        f"Clean BER: {first_ber_percent(read_text('baseline_report.txt'))}",
        f"Translation stress BER sample: {first_ber_percent(read_text('translation_report.txt'))}",
        f"Crop stress BER sample: {first_ber_percent(read_text('crop_report.txt'))}",
        f"Rotation stress BER sample: {first_ber_percent(read_text('rotation_report.txt'))}",
        f"Scaling stress BER sample: {first_ber_percent(read_text('scaling_report.txt'))}",
        f"Composite stress BER: {first_ber_percent(read_text('composite_report.txt'))}",
        f"Defense BER: {float(defense.get('ber', 1.0)) * 100.0:.2f}%",
        f"Defense config changed: {defense.get('config_changed', False)}",
        f"Plan: {'accepted' if 'Defense plan accepted' in read_text('plan_report.txt') else 'missing'}",
        f"Memo: {'accepted' if 'Defense memo accepted' in read_text('memo_report.txt') else 'missing'}",
        f"Visual sheet: {'created' if 'Defense visual comparison completed' in read_text('visual_defense_report.txt') else 'missing'}",
        "Trade-off: increasing ALPHA and REPEAT_N usually improves robustness but can reduce imperceptibility and capacity.",
        "Mid-frequency DCT coefficients balance visibility and resistance better than very low or very high frequencies.",
    ]
    write_report(work_path("summary_report.txt"), lines)
    for line in lines:
        print(line)


if __name__ == "__main__":
    main()
