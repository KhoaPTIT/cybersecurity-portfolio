"""
Student-tuned defense parameters.

The starter values are intentionally too small. Task 9 requires editing this
file after inspecting the BER tables and the visual attack outputs.
"""

# Increase embedding strength only as far as needed. Too high makes stego
# artifacts easier to see in the difference and contact-sheet images.
ALPHA = 20.0

# Majority voting is the first line of defense against interpolation noise.
REPEAT_N = 3

# Search how far the defense may shift an attacked image back into alignment.
SEARCH_RADIUS = 2

# Add small rotation hypotheses around the attack you observed.
ROTATION_CANDIDATES = [0]

# A 10 percent crop leaves roughly 90 percent of the original field of view.
SCALE_CANDIDATES = [1.0]
