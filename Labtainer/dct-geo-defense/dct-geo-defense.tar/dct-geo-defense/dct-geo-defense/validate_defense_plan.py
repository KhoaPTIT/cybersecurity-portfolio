from __future__ import annotations

import ast
import re

from dct_helper import read_json, work_path, write_report


PLAN = work_path("DEFENSE_PLAN.md")


def parse_assignment(text: str, name: str) -> str | None:
    match = re.search(rf"^{name}\s*=\s*(.+)$", text, flags=re.MULTILINE)
    return match.group(1).strip() if match else None


def parse_list(value: str) -> list:
    parsed = ast.literal_eval(value)
    if not isinstance(parsed, list):
        raise ValueError("not a list")
    return parsed


def main() -> int:
    text = PLAN.read_text(encoding="utf-8") if PLAN.exists() else ""
    sweep_rows = read_json(work_path("sweep_metrics.json"), {"rows": []}).get("rows", [])
    benchmark_exists = work_path("benchmark_report.txt").exists()
    errors: list[str] = []

    if "TODO" in text or "..." in text:
        errors.append("remove TODO/... placeholders")
    if len(text) < 650:
        errors.append("plan is too short")
    if not sweep_rows:
        errors.append("run parameter_sweep.py before validating the plan")
    if not benchmark_exists:
        errors.append("run build_geometric_benchmark.py before validating the plan")

    try:
        alpha = float(parse_assignment(text, "ALPHA") or "nan")
        if not 25.0 <= alpha <= 60.0:
            errors.append("ALPHA must be between 25 and 60")
    except ValueError:
        errors.append("ALPHA must be numeric")

    try:
        repeat = int(parse_assignment(text, "REPEAT_N") or "0")
        if repeat < 5:
            errors.append("REPEAT_N must be at least 5")
    except ValueError:
        errors.append("REPEAT_N must be an integer")

    try:
        radius = int(parse_assignment(text, "SEARCH_RADIUS") or "0")
        if radius < 8:
            errors.append("SEARCH_RADIUS must be at least 8")
    except ValueError:
        errors.append("SEARCH_RADIUS must be an integer")

    try:
        rotations = parse_list(parse_assignment(text, "ROTATION_CANDIDATES") or "[]")
        if len(rotations) < 5 or 0 not in rotations:
            errors.append("ROTATION_CANDIDATES must include 0 and several nearby angles")
    except Exception:
        errors.append("ROTATION_CANDIDATES must be a Python list")

    try:
        scales = parse_list(parse_assignment(text, "SCALE_CANDIDATES") or "[]")
        if len(scales) < 4 or not any(0.88 <= float(item) <= 0.92 for item in scales):
            errors.append("SCALE_CANDIDATES must include values near 0.90")
    except Exception:
        errors.append("SCALE_CANDIDATES must be a Python list")

    hardest = (parse_assignment(text, "HARDEST_TRANSFORM") or "").lower()
    if hardest not in {"translation", "crop", "rotation", "scaling", "composite"}:
        errors.append("HARDEST_TRANSFORM must name a benchmark case")

    passed = not errors
    lines = ["Defense plan accepted" if passed else "Defense plan rejected"]
    lines.extend(errors or ["Plan contains parameter choices, benchmark evidence, and rationale."])
    write_report(work_path("plan_report.txt"), lines)
    for line in lines:
        print(line)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
