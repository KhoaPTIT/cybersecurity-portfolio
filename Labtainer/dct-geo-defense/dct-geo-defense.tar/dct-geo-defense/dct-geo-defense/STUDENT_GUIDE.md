# STUDENT_GUIDE - dct-geo-defense

Lab nay la bai phong thu. Ban phai doc bang ket qua, quan sat anh, viet plan, sua cau hinh, chay thu defense, va viet memo. Neu chi copy mot day lenh thi se khong pass vi `DEFENSE_PLAN.md` va `DEFENSE_MEMO.md` con placeholder.

## Task 1 - Calibrate DCT Embedding

```bash
python3 calibrate_dct_defense.py --alpha 35 --repeat 5
eog cover.png &
eog stego.png &
eog dct_spectrum_before.png &
cat embed_report.txt
```

Ban can nhin anh cover/stego va doc PSNR. Neu stego qua de nhin thay, thu lai voi alpha khac.

## Task 2 - Sweep Parameter Trade-off

```bash
python3 parameter_sweep.py --alphas 25,35,45,55 --repeats 3,5,7
cat sweep_report.txt
```

Chon mot dong co PSNR tot va composite BER khong qua cao. Dong nay la bang chung dau tien cho plan.

## Task 3 - Build Defense Benchmark

```bash
python3 build_geometric_benchmark.py
ls attacks
eog attacks/composite_attacked.png &
cat benchmark_report.txt
cat translation_report.txt
cat crop_report.txt
cat rotation_report.txt
cat scaling_report.txt
cat composite_report.txt
```

Day la bo stress-test de thiet ke phong thu. Ban khong chay tung attack rieng le; ban doc benchmark de biet defense can chong lech translation, crop zoom, rotation hay composite.

## Task 4 - Write Defense Plan

Mo file plan:

```bash
nano DEFENSE_PLAN.md
```

Thay tat ca `TODO` bang quyet dinh cua ban. Vi du cac dong tham so phai co dang:

```text
ALPHA = 35.0
REPEAT_N = 5
SEARCH_RADIUS = 8
ROTATION_CANDIDATES = [-5, -3, -1, 0, 1, 3, 5]
SCALE_CANDIDATES = [0.90, 0.95, 1.0, 1.05, 1.10]
HARDEST_TRANSFORM = composite
```

Phan Evidence phai cite it nhat hai so BER/PSNR tu report va mot dau hieu truc quan tu anh. Kiem tra:

```bash
python3 validate_defense_plan.py
cat plan_report.txt
```

## Task 5 - Generate And Review Config

```bash
python3 apply_plan_to_config.py
nano defense_config.py
cat config_report.txt
```

Buoc nay bien plan thanh cau hinh Python. Ban duoc phep sua `defense_config.py` tiep neu thay can.

## Task 6 - Run Resynchronization Defense

```bash
python3 registration_defense.py
cat defense_report.txt
eog defended.png &
```

Neu fail, quay lai Task 4-5: sua plan/config, roi chay lai defense.

## Task 7 - Visual Evidence Board

```bash
python3 visualize_defense.py
eog defense_contact_sheet.png &
cat visual_defense_report.txt
```

Anh board nay dung de so sanh cover, stego, composite attacked, defended va cac anh difference.

## Task 8 - Defense Memo

Mo memo:

```bash
nano DEFENSE_MEMO.md
```

Viet du 4 muc: Visual Evidence, Quantitative Evidence, What I Changed, Residual Risk. Sau do chay:

```bash
python3 validate_defense_memo.py
cat memo_report.txt
```

## Task 9 - Summary And Checkwork

```bash
python3 summary.py
cat summary_report.txt
checkwork
```

Dung lab:

```bash
stoplab dct-geo-defense
```
