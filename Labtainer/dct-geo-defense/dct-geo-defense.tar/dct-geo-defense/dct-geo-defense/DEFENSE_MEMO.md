# Defense Memo

Fill this after `registration_defense.py` and `visualize_defense.py`.

## Visual Evidence

TODO: compare `composite_attacked.png`, `defended.png`, and `defense_contact_sheet.png`.

## Quantitative Evidence

TODO: cite PSNR and final defense BER from `defense_report.txt`.

## What I Changed

TODO: describe what you changed in `defense_config.py` and why.

## Residual Risk

TODO: describe one geometric case where this defense may still fail.
