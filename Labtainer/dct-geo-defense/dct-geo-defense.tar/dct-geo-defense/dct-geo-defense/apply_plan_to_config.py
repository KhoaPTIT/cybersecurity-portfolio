from __future__ import annotations

import re

from dct_helper import work_path, write_report


PLAN = work_path("DEFENSE_PLAN.md")
CONFIG = work_path("defense_config.py")


def assignment(text: str, name: str) -> str:
    match = re.search(rf"^{name}\s*=\s*(.+)$", text, flags=re.MULTILINE)
    if not match:
        raise ValueError(f"missing {name} in DEFENSE_PLAN.md")
    return match.group(1).strip()


def main() -> None:
    text = PLAN.read_text(encoding="utf-8")
    values = {
        "ALPHA": assignment(text, "ALPHA"),
        "REPEAT_N": assignment(text, "REPEAT_N"),
        "SEARCH_RADIUS": assignment(text, "SEARCH_RADIUS"),
        "ROTATION_CANDIDATES": assignment(text, "ROTATION_CANDIDATES"),
        "SCALE_CANDIDATES": assignment(text, "SCALE_CANDIDATES"),
    }
    CONFIG.write_text(
        "\n".join(
            [
                '"""Student defense configuration generated from DEFENSE_PLAN.md."""',
                f"ALPHA = {values['ALPHA']}",
                f"REPEAT_N = {values['REPEAT_N']}",
                f"SEARCH_RADIUS = {values['SEARCH_RADIUS']}",
                f"ROTATION_CANDIDATES = {values['ROTATION_CANDIDATES']}",
                f"SCALE_CANDIDATES = {values['SCALE_CANDIDATES']}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    write_report(
        work_path("config_report.txt"),
        [
            "Defense config generated from plan",
            f"ALPHA: {values['ALPHA']}",
            f"REPEAT_N: {values['REPEAT_N']}",
            f"SEARCH_RADIUS: {values['SEARCH_RADIUS']}",
            f"ROTATION_CANDIDATES: {values['ROTATION_CANDIDATES']}",
            f"SCALE_CANDIDATES: {values['SCALE_CANDIDATES']}",
        ],
    )
    print("Updated defense_config.py from DEFENSE_PLAN.md.")
    print("Open defense_config.py and verify the values before running registration_defense.py.")


if __name__ == "__main__":
    main()
