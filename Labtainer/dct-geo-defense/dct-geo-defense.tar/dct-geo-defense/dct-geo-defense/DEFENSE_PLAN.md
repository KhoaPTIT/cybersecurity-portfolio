# Defense Plan

Replace every TODO with your own decision after reading `sweep_report.txt`,
`benchmark_report.txt`, and the images in `attacks/`.

ALPHA = TODO
REPEAT_N = TODO
SEARCH_RADIUS = TODO
ROTATION_CANDIDATES = TODO
SCALE_CANDIDATES = TODO
HARDEST_TRANSFORM = TODO

## Evidence

TODO: cite at least two BER numbers and one visual clue from the generated images.

## Design Rationale

TODO: explain why your parameters trade off PSNR, robustness, and runtime.
