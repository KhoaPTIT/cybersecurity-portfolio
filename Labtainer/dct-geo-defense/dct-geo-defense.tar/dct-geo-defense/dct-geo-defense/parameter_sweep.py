from __future__ import annotations

import argparse

from geo_attack import composite_attack, open_rgb, save_attack
from dct_helper import (
    embed_message,
    ensure_cover,
    extract_message,
    read_json,
    terminal_text,
    work_path,
    write_json,
    write_report,
)


def parse_numbers(text: str, cast):
    values = []
    for item in text.split(","):
        item = item.strip()
        if item:
            values.append(cast(item))
    if not values:
        raise ValueError("empty sweep list")
    return values


def main() -> None:
    parser = argparse.ArgumentParser(description="Sweep DCT defense embedding parameters before choosing a design.")
    parser.add_argument("--alphas", default="20,30,35,45,55", help="Comma-separated embedding strengths.")
    parser.add_argument("--repeats", default="3,5,7", help="Comma-separated repetition counts.")
    args = parser.parse_args()

    alphas = parse_numbers(args.alphas, float)
    repeats = parse_numbers(args.repeats, int)
    cover = ensure_cover()
    rows = []

    for alpha in alphas:
        for repeat in repeats:
            stego_name = f"_sweep_a{int(alpha)}_r{repeat}.png"
            metrics = embed_message(cover, work_path(stego_name), alpha=alpha, repeat_n=repeat)
            clean = extract_message(work_path(stego_name), repeat_n=repeat)
            attacked = work_path(f"_sweep_composite_a{int(alpha)}_r{repeat}.png")
            save_attack(composite_attack(open_rgb(work_path(stego_name)), angle=3, dx=5, dy=5, crop_percent=0.10), attacked)
            attacked_result = extract_message(attacked, repeat_n=repeat)
            rows.append(
                {
                    "alpha": alpha,
                    "repeat": repeat,
                    "psnr": metrics["psnr"],
                    "clean_ber": clean["ber"],
                    "composite_ber": attacked_result["ber"],
                    "message": attacked_result["message"],
                }
            )

    rows.sort(key=lambda row: (row["composite_ber"], -row["psnr"], row["repeat"], row["alpha"]))
    write_json(work_path("sweep_metrics.json"), {"rows": rows})

    lines = [
        "Parameter sweep completed",
        "alpha,repeat,PSNR_dB,clean_BER_percent,composite_BER_percent,recovered_after_composite",
    ]
    for row in rows:
        lines.append(
            f"{row['alpha']:.1f},{row['repeat']},{row['psnr']:.2f},"
            f"{row['clean_ber'] * 100.0:.2f},{row['composite_ber'] * 100.0:.2f},{row['message']}"
        )
    best = rows[0]
    lines.append(
        f"Suggested starting point: ALPHA={best['alpha']:.1f}, REPEAT_N={best['repeat']} "
        f"because composite BER={best['composite_ber'] * 100.0:.2f}% and PSNR={best['psnr']:.2f} dB."
    )
    write_report(work_path("sweep_report.txt"), lines)

    # Keep a normal stego.png from the best non-attack trade-off for later visual inspection.
    chosen = read_json(work_path("sweep_metrics.json"), {"rows": []})["rows"][0]
    embed_message(cover, work_path("stego.png"), alpha=chosen["alpha"], repeat_n=chosen["repeat"])
    print("Parameter sweep completed.")
    print(f"Best row alpha={chosen['alpha']:.1f} repeat={chosen['repeat']} composite_ber={chosen['composite_ber'] * 100.0:.2f}%")
    print(f"Recovered sample={terminal_text(chosen['message'])}")
    print("Read sweep_report.txt, then decide which values belong in defense_config.py.")


if __name__ == "__main__":
    main()
