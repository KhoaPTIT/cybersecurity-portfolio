from __future__ import annotations

import subprocess
import sys
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parent
COMMANDS = [
    ["calibrate_dct_defense.py", "--alpha", "35", "--repeat", "5"],
    ["parameter_sweep.py", "--alphas", "25,35,45", "--repeats", "5,7"],
    ["build_geometric_benchmark.py"],
    ["validate_defense_plan.py"],
    ["apply_plan_to_config.py"],
    ["registration_defense.py"],
    ["visualize_defense.py"],
    ["validate_defense_memo.py"],
    ["summary.py"],
]
CHECKS = {
    "embed_report.txt": "Defense embedding calibration completed",
    "sweep_report.txt": "Parameter sweep completed",
    "benchmark_report.txt": "Geometric defense benchmark completed",
    "plan_report.txt": "Defense plan accepted",
    "config_report.txt": "Defense config generated from plan",
    "defense_report.txt": "Geometric resynchronization defense PASSED",
    "visual_defense_report.txt": "Defense visual comparison completed",
    "memo_report.txt": "Defense memo accepted",
    "summary_report.txt": "Summary Completed",
}


def maybe_write_solution_config() -> None:
    if os.environ.get("DCT_DEFENSE_SELFTEST_SOLUTION") != "1":
        return
    (ROOT / "defense_config.py").write_text(
        "\n".join(
            [
                '"""Self-test solution parameters for instructor packaging."""',
                "ALPHA = 35.0",
                "REPEAT_N = 5",
                "SEARCH_RADIUS = 8",
                "ROTATION_CANDIDATES = [-5, -3, -1, 0, 1, 3, 5]",
                "SCALE_CANDIDATES = [0.90, 0.95, 1.0, 1.05, 1.10]",
                "",
            ]
        ),
        encoding="utf-8",
    )
    (ROOT / "DEFENSE_PLAN.md").write_text(
        "\n".join(
            [
                "# Defense Plan",
                "",
                "ALPHA = 35.0",
                "REPEAT_N = 5",
                "SEARCH_RADIUS = 8",
                "ROTATION_CANDIDATES = [-5, -3, -1, 0, 1, 3, 5]",
                "SCALE_CANDIDATES = [0.90, 0.95, 1.0, 1.05, 1.10]",
                "HARDEST_TRANSFORM = composite",
                "",
                "## Evidence",
                "",
                "The sweep report keeps PSNR above 35 dB while repeat 5 gives clean extraction. "
                "The benchmark shows the composite case is the hardest because it combines crop zoom, rotation, and translation. "
                "The visual clue is the gray border and blur around the composite image, which indicates lost block synchronization.",
                "",
                "## Design Rationale",
                "",
                "I choose ALPHA 35 and repeat 5 because they keep visible distortion low while giving majority vote redundancy. "
                "The search radius covers the observed 5 pixel shift with margin. Rotation candidates cover small positive and negative angles, "
                "and scale candidates include 0.90 to compensate for the 10 percent crop.",
                "",
            ]
        ),
        encoding="utf-8",
    )
    (ROOT / "DEFENSE_MEMO.md").write_text(
        "\n".join(
            [
                "# Defense Memo",
                "",
                "## Visual Evidence",
                "",
                "The composite attacked image has gray border fill and visible interpolation blur, while defended.png is closer to the original stego alignment. "
                "In defense_contact_sheet.png the stego versus defended difference is still visible, but it is more structured than the composite attacked panel and the block drift is reduced.",
                "",
                "## Quantitative Evidence",
                "",
                "The defense report lists PSNR above 35 dB and final Defense BER below the required 15 percent threshold. "
                "The benchmark report shows the composite stress case is worse than clean extraction, so the defense improves the practical extraction case instead of only passing a clean image.",
                "",
                "## What I Changed",
                "",
                "I changed ALPHA to 35, REPEAT_N to 5, SEARCH_RADIUS to 8, and added rotation and scale candidates around the observed transform. "
                "These changes give the extractor enough redundancy and enough geometric hypotheses to recover synchronization.",
                "",
                "## Residual Risk",
                "",
                "The defense may still fail on larger rotations, severe crop, or nonuniform perspective transforms because the current search only tests global scale, rotation, and translation. "
                "A stronger system would need feature based registration or synchronization markers.",
                "",
            ]
        ),
        encoding="utf-8",
    )


def remove_outputs() -> None:
    patterns = [
        "*.png",
        "*.txt",
        "*.json",
        "_defense_candidate.png",
        "attacks/*.png",
    ]
    for pattern in patterns:
        for path in ROOT.glob(pattern):
            if path.name in {"STUDENT_GUIDE.md"}:
                continue
            if path.is_file():
                path.unlink()
    attacks = ROOT / "attacks"
    if attacks.exists() and not any(attacks.iterdir()):
        attacks.rmdir()


def run_command(command: list[str]) -> bool:
    proc = subprocess.run([sys.executable, *command], cwd=ROOT, text=True, capture_output=True)
    if proc.returncode != 0:
        print(f"FAIL {' '.join(command)}")
        print(proc.stdout)
        print(proc.stderr)
        return False
    print(f"PASS {' '.join(command)}")
    return True


def check_reports() -> bool:
    ok = True
    for name, needle in CHECKS.items():
        path = ROOT / name
        text = path.read_text(encoding="utf-8") if path.exists() else ""
        if needle in text:
            print(f"PASS check {name}")
        else:
            print(f"FAIL check {name}: missing {needle}")
            ok = False
    return ok


def main() -> int:
    remove_outputs()
    maybe_write_solution_config()
    ok = True
    for command in COMMANDS:
        ok = run_command(command) and ok
    ok = check_reports() and ok
    print("PASS selftest_local.py" if ok else "FAIL selftest_local.py")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
