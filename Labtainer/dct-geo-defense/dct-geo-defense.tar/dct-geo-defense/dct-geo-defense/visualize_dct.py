import numpy as np
from PIL import Image

from dct_helper import BLOCK_SIZE, dct2, ensure_cover, load_gray, work_path, write_report


def main() -> None:
    cover = ensure_cover()
    gray = load_gray(cover)
    spectrum = np.zeros((BLOCK_SIZE, BLOCK_SIZE), dtype=np.float64)
    blocks = 0
    for y in range(0, gray.shape[0], BLOCK_SIZE):
        for x in range(0, gray.shape[1], BLOCK_SIZE):
            coeff = dct2(gray[y : y + BLOCK_SIZE, x : x + BLOCK_SIZE] - 128.0)
            spectrum += np.log1p(np.abs(coeff))
            blocks += 1
    spectrum /= blocks
    spectrum = spectrum - spectrum.min()
    spectrum = spectrum / max(float(spectrum.max()), 1e-9)
    heatmap = np.kron((spectrum * 255).astype(np.uint8), np.ones((64, 64), dtype=np.uint8))
    Image.fromarray(heatmap, mode="L").convert("RGB").save(work_path("dct_spectrum_before.png"))
    write_report(work_path("visual_report.txt"), ["DCT spectrum visualized", "Source image: cover.png"])
    print("Wrote dct_spectrum_before.png and visual_report.txt")


if __name__ == "__main__":
    main()
