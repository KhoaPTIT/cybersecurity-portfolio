from __future__ import annotations

from geo_attack import (
    composite_attack,
    crop_resize_image,
    open_rgb,
    rotate_image,
    save_attack,
    scale_down_up_image,
    translate_image,
)
from dct_helper import REPEAT_N, ensure_stego, extract_message, terminal_text, work_path, write_json, write_report


TRANSLATIONS = [(2, 2), (5, 5), (10, 10), (20, 20)]
CROPS = [5, 10, 20, 30]
ROTATIONS = [1, 3, 5, 10]
SCALES = [90, 75, 50]


def row_line(row: dict, fields: list[str]) -> str:
    values = [str(row[field]) for field in fields]
    values.append(f"{row['ber'] * 100.0:.2f}")
    values.append(row["message"])
    return ",".join(values)


def main() -> None:
    stego = ensure_stego()
    img = open_rgb(stego)
    benchmark = {}

    translation_rows = []
    for dx, dy in TRANSLATIONS:
        out = work_path(f"attacks/translation_{dx}_{dy}.png")
        save_attack(translate_image(img, dx, dy), out)
        result = extract_message(out, repeat_n=REPEAT_N)
        translation_rows.append({"dx": dx, "dy": dy, "ber": result["ber"], "message": result["message"]})
    benchmark["translation"] = translation_rows
    write_json(work_path("translation_metrics.json"), {"rows": translation_rows})
    write_report(
        work_path("translation_report.txt"),
        ["Translation Defense Stress Profile", "dx,dy,BER_percent,recovered_message"]
        + [row_line(row, ["dx", "dy"]) for row in translation_rows],
    )

    crop_rows = []
    for percent in CROPS:
        out = work_path(f"attacks/crop_{percent}.png")
        save_attack(crop_resize_image(img, percent / 100.0), out)
        result = extract_message(out, repeat_n=REPEAT_N)
        crop_rows.append({"percent": percent, "ber": result["ber"], "message": result["message"]})
    benchmark["crop"] = crop_rows
    write_json(work_path("crop_metrics.json"), {"rows": crop_rows})
    write_report(
        work_path("crop_report.txt"),
        ["Crop Defense Stress Profile", "crop_percent,BER_percent,recovered_message"]
        + [row_line(row, ["percent"]) for row in crop_rows],
    )

    rotation_rows = []
    for angle in ROTATIONS:
        out = work_path(f"attacks/rotation_{angle}.png")
        save_attack(rotate_image(img, angle), out)
        result = extract_message(out, repeat_n=REPEAT_N)
        rotation_rows.append({"angle": angle, "ber": result["ber"], "message": result["message"]})
    benchmark["rotation"] = rotation_rows
    write_json(work_path("rotation_metrics.json"), {"rows": rotation_rows})
    write_report(
        work_path("rotation_report.txt"),
        ["Rotation Defense Stress Profile", "angle,BER_percent,recovered_message"]
        + [row_line(row, ["angle"]) for row in rotation_rows],
    )

    scaling_rows = []
    for scale in SCALES:
        out = work_path(f"attacks/scaling_{scale}.png")
        save_attack(scale_down_up_image(img, scale / 100.0), out)
        result = extract_message(out, repeat_n=REPEAT_N)
        scaling_rows.append({"scale": scale, "ber": result["ber"], "message": result["message"]})
    benchmark["scaling"] = scaling_rows
    write_json(work_path("scaling_metrics.json"), {"rows": scaling_rows})
    write_report(
        work_path("scaling_report.txt"),
        ["Scaling Defense Stress Profile", "scale_percent,BER_percent,recovered_message"]
        + [row_line(row, ["scale"]) for row in scaling_rows],
    )

    composite_out = work_path("attacks/composite_attacked.png")
    save_attack(composite_attack(img, angle=3, dx=5, dy=5, crop_percent=0.10), composite_out)
    save_attack(open_rgb(composite_out), work_path("composite_attacked.png"))
    composite_result = extract_message(composite_out, repeat_n=REPEAT_N)
    composite_row = {"angle": 3, "dx": 5, "dy": 5, "crop": 10, "ber": composite_result["ber"], "message": composite_result["message"]}
    benchmark["composite"] = [composite_row]
    write_json(work_path("composite_metrics.json"), composite_row)
    write_report(
        work_path("composite_report.txt"),
        [
            "Composite Defense Stress Profile",
            "attack=rotate 3 degree, translate 5,5 px, crop 10 percent",
            f"BER: {composite_result['ber'] * 100.0:.2f}%",
            f"Recovered message: {composite_result['message']}",
        ],
    )
    write_json(work_path("defense_benchmark.json"), benchmark)
    write_report(
        work_path("benchmark_report.txt"),
        [
            "Geometric defense benchmark completed",
            f"translation cases: {len(translation_rows)}",
            f"crop cases: {len(crop_rows)}",
            f"rotation cases: {len(rotation_rows)}",
            f"scaling cases: {len(scaling_rows)}",
            f"composite BER: {composite_result['ber'] * 100.0:.2f}%",
            "Use this report to choose HARDEST_TRANSFORM and search ranges in DEFENSE_PLAN.md.",
        ],
    )

    print("Defense stress benchmark completed.")
    print("Open attacks/ and compare which geometric distortion breaks synchronization most.")
    print(f"Composite BER={composite_result['ber'] * 100.0:.2f}% recovered={terminal_text(composite_result['message'])}")


if __name__ == "__main__":
    main()
