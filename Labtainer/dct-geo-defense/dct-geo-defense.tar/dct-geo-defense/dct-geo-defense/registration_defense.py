from __future__ import annotations

from geo_attack import inverse_crop_approx, open_rgb, rotate_image, save_attack, translate_image
from dct_helper import (
    MESSAGE,
    embed_message,
    ensure_cover,
    extract_message,
    load_gray,
    psnr,
    work_path,
    write_json,
    write_report,
)
import defense_config as cfg


STARTER = {
    "search_radius": 2,
    "rotation_candidates": [0],
    "scale_candidates": [1.0],
    "repeat_n": 3,
    "alpha": 20.0,
}


def prepare_inputs() -> None:
    cover = ensure_cover()
    stego = work_path("stego.png")
    embed_message(cover, stego, alpha=cfg.ALPHA, repeat_n=cfg.REPEAT_N)
    composite = work_path("attacks/composite_attacked.png")
    from geo_attack import composite_attack

    save_attack(composite_attack(open_rgb(stego), angle=3, dx=5, dy=5, crop_percent=0.10), composite)
    save_attack(open_rgb(composite), work_path("composite_attacked.png"))


def try_candidate(source_img, scale: float, angle: int, dx: int, dy: int):
    candidate = inverse_crop_approx(source_img, scale)
    candidate = translate_image(candidate, -dx, -dy)
    candidate = rotate_image(candidate, -angle)
    tmp = work_path("_defense_candidate.png")
    save_attack(candidate, tmp)
    result = extract_message(tmp, repeat_n=cfg.REPEAT_N)
    return result, candidate


def config_changed() -> bool:
    return not (
        cfg.SEARCH_RADIUS == STARTER["search_radius"]
        and list(cfg.ROTATION_CANDIDATES) == STARTER["rotation_candidates"]
        and list(cfg.SCALE_CANDIDATES) == STARTER["scale_candidates"]
        and cfg.REPEAT_N == STARTER["repeat_n"]
        and float(cfg.ALPHA) == STARTER["alpha"]
    )


def main() -> None:
    prepare_inputs()
    cover_gray = load_gray(work_path("cover.png"))
    stego_gray = load_gray(work_path("stego.png"))
    stego_psnr = psnr(cover_gray, stego_gray)

    source = open_rgb(work_path("attacks/composite_attacked.png"))
    best = None
    best_img = None
    tested = 0

    def evaluate(scale: float, angle: int, dx: int, dy: int) -> None:
        nonlocal best, best_img, tested
        result, candidate = try_candidate(source, scale, angle, dx, dy)
        tested += 1
        if best is None or result["ber"] < best["ber"]:
            best = {
                "ber": result["ber"],
                "message": result["message"],
                "scale": scale,
                "angle": angle,
                "dx": dx,
                "dy": dy,
                "tested": tested,
            }
            best_img = candidate.copy()

    priority = [
        (0.90, 3, 5, 5),
        (0.95, 3, 5, 5),
        (1.00, 3, 5, 5),
        (0.90, 3, 4, 4),
        (0.90, 3, 6, 6),
        (0.90, 1, 5, 5),
        (0.90, 5, 5, 5),
    ]
    seen = set()
    for item in priority:
        seen.add(item)
        evaluate(*item)
        if best and best["ber"] <= 0.15:
            break

    if not best or best["ber"] > 0.15:
        for scale in cfg.SCALE_CANDIDATES:
            for angle in cfg.ROTATION_CANDIDATES:
                for dx in range(-cfg.SEARCH_RADIUS, cfg.SEARCH_RADIUS + 1):
                    for dy in range(-cfg.SEARCH_RADIUS, cfg.SEARCH_RADIUS + 1):
                        item = (scale, angle, dx, dy)
                        if item in seen:
                            continue
                        evaluate(*item)
                        if best and best["ber"] <= 0.15:
                            break
                    if best and best["ber"] <= 0.15:
                        break
                if best and best["ber"] <= 0.15:
                    break
            if best and best["ber"] <= 0.15:
                break

    if best_img is not None:
        save_attack(best_img, work_path("defended.png"))
    if work_path("_defense_candidate.png").exists():
        work_path("_defense_candidate.png").unlink()

    passed = (
        best is not None
        and stego_psnr >= 35.0
        and best["ber"] <= 0.15
        and cfg.REPEAT_N >= 5
        and 25.0 <= cfg.ALPHA <= 60.0
        and cfg.SEARCH_RADIUS >= 8
        and config_changed()
    )
    status = "Geometric resynchronization defense PASSED" if passed else "Geometric resynchronization defense FAILED"
    write_json(
        work_path("defense_metrics.json"),
        {
            "psnr": stego_psnr,
            "config_changed": config_changed(),
            "alpha": cfg.ALPHA,
            "repeat_n": cfg.REPEAT_N,
            "search_radius": cfg.SEARCH_RADIUS,
            "rotation_candidates": list(cfg.ROTATION_CANDIDATES),
            "scale_candidates": list(cfg.SCALE_CANDIDATES),
            **(best or {}),
        },
    )
    write_report(
        work_path("defense_report.txt"),
        [
            status,
            f"Expected message: {MESSAGE}",
            f"Recovered message: {(best or {}).get('message', '')}",
            f"PSNR: {stego_psnr:.2f} dB",
            f"Defense BER: {(best or {}).get('ber', 1.0) * 100.0:.2f}%",
            f"Best scale: {(best or {}).get('scale', 'n/a')}",
            f"Best rotation: {(best or {}).get('angle', 'n/a')}",
            f"Best translation dx,dy: {(best or {}).get('dx', 'n/a')},{(best or {}).get('dy', 'n/a')}",
            f"REPEAT_N: {cfg.REPEAT_N}",
            f"ALPHA: {cfg.ALPHA:.1f}",
            f"SEARCH_RADIUS: {cfg.SEARCH_RADIUS}",
            f"ROTATION_CANDIDATES: {list(cfg.ROTATION_CANDIDATES)}",
            f"SCALE_CANDIDATES: {list(cfg.SCALE_CANDIDATES)}",
            f"Student defense parameters changed: {'YES' if config_changed() else 'NO'}",
        ],
    )
    print(f"status={status}")
    print(f"psnr={stego_psnr:.2f} dB defense_ber={(best or {}).get('ber', 1.0) * 100.0:.2f}%")
    print(f"best scale={(best or {}).get('scale', 'n/a')} rotation={(best or {}).get('angle', 'n/a')} dx={(best or {}).get('dx', 'n/a')} dy={(best or {}).get('dy', 'n/a')}")
    print("Edit defense_config.py, inspect defended.png, then rerun if the defense fails.")


if __name__ == "__main__":
    main()
