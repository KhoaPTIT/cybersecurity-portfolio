from __future__ import annotations

import argparse

import numpy as np
from PIL import Image

from dct_helper import (
    BLOCK_SIZE,
    MESSAGE,
    dct2,
    embed_message,
    ensure_cover,
    extract_message,
    load_gray,
    terminal_text,
    work_path,
    write_report,
)


def write_spectrum() -> None:
    gray = load_gray(work_path("cover.png"))
    spectrum = np.zeros((BLOCK_SIZE, BLOCK_SIZE), dtype=np.float64)
    blocks = 0
    for y in range(0, gray.shape[0], BLOCK_SIZE):
        for x in range(0, gray.shape[1], BLOCK_SIZE):
            coeff = dct2(gray[y : y + BLOCK_SIZE, x : x + BLOCK_SIZE] - 128.0)
            spectrum += np.log1p(np.abs(coeff))
            blocks += 1
    spectrum /= blocks
    spectrum = spectrum - spectrum.min()
    spectrum = spectrum / max(float(spectrum.max()), 1e-9)
    heatmap = np.kron((spectrum * 255).astype(np.uint8), np.ones((64, 64), dtype=np.uint8))
    Image.fromarray(heatmap, mode="L").convert("RGB").save(work_path("dct_spectrum_before.png"))


def main() -> None:
    parser = argparse.ArgumentParser(description="Calibrate the DCT watermark defense before geometric stress tests.")
    parser.add_argument("--alpha", type=float, default=35.0, help="Embedding strength to evaluate.")
    parser.add_argument("--repeat", type=int, default=5, help="Repetition count to evaluate.")
    args = parser.parse_args()

    cover = ensure_cover()
    metrics = embed_message(cover, work_path("stego.png"), alpha=args.alpha, repeat_n=args.repeat)
    result = extract_message(work_path("stego.png"), repeat_n=args.repeat)
    write_spectrum()

    clean_ok = result["ber"] == 0.0
    write_report(
        work_path("embed_report.txt"),
        [
            "Defense embedding calibration completed",
            f"Message: {metrics['message']}",
            f"ALPHA: {metrics['alpha']:.1f}",
            f"REPEAT_N: {metrics['repeat_n']}",
            f"PSNR: {metrics['psnr']:.2f} dB",
            "Decision: keep PSNR above 35 dB before adding geometric resynchronization.",
        ],
    )
    write_report(
        work_path("baseline_report.txt"),
        [
            "Clean defense extraction BER = 0.00%" if clean_ok else f"Clean defense extraction BER = {result['ber'] * 100.0:.2f}%",
            f"Expected message: {MESSAGE}",
            f"Recovered message: {result['message']}",
            f"REPEAT_N: {result['repeat_n']}",
        ],
    )
    write_report(
        work_path("visual_report.txt"),
        [
            "DCT defense spectrum visualized",
            "Output: dct_spectrum_before.png",
            "Inspect where mid-frequency coefficients sit before choosing defense parameters.",
        ],
    )
    print(f"calibration alpha={args.alpha:.1f} repeat={args.repeat} psnr={metrics['psnr']:.2f} dB")
    print(f"clean_ber={result['ber'] * 100.0:.2f}% recovered={terminal_text(result['message'])}")
    print("Open cover.png, stego.png, and dct_spectrum_before.png before tuning defense_config.py.")


if __name__ == "__main__":
    main()
