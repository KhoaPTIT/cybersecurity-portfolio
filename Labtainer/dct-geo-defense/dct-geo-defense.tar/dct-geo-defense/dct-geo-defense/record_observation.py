from __future__ import annotations

import argparse

from dct_helper import read_json, work_path, write_json, write_report


REQUIRED_CASES = {"translation", "crop", "rotation", "scaling", "composite", "defense"}
MIN_NOTE_LEN = 35


def main() -> None:
    parser = argparse.ArgumentParser(description="Record a manual visual observation for checkwork.")
    parser.add_argument("--case", required=True, choices=sorted(REQUIRED_CASES))
    parser.add_argument("--note", required=True, help="What you saw in the image output. Minimum 35 characters.")
    parser.add_argument("--decision", required=True, help="How this observation changed your defense choice.")
    args = parser.parse_args()

    note = " ".join(args.note.split())
    decision = " ".join(args.decision.split())
    data = read_json(work_path("observations.json"), {"rows": []})
    rows = [row for row in data.get("rows", []) if row.get("case") != args.case]
    rows.append({"case": args.case, "note": note, "decision": decision})
    rows.sort(key=lambda row: row["case"])
    write_json(work_path("observations.json"), {"rows": rows})

    complete_cases = {row.get("case") for row in rows}
    long_enough = all(len(row.get("note", "")) >= MIN_NOTE_LEN and len(row.get("decision", "")) >= 20 for row in rows)
    complete = REQUIRED_CASES.issubset(complete_cases) and long_enough

    lines = ["Manual visual observations completed" if complete else "Manual visual observations in progress"]
    lines.append("Required cases: " + ", ".join(sorted(REQUIRED_CASES)))
    for row in rows:
        lines.append(f"{row['case']}: note_len={len(row['note'])} decision_len={len(row['decision'])}")
        lines.append(f"  note: {row['note']}")
        lines.append(f"  decision: {row['decision']}")
    write_report(work_path("observation_report.txt"), lines)

    print(lines[0])
    missing = sorted(REQUIRED_CASES - complete_cases)
    if missing:
        print("Missing cases: " + ", ".join(missing))
    if not long_enough:
        print("Each note must be at least 35 characters and each decision at least 20 characters.")


if __name__ == "__main__":
    main()
