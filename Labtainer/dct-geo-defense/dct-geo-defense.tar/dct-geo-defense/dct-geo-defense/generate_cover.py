from dct_helper import generate_cover, work_path


def main() -> None:
    generate_cover(work_path("cover.png"))
    print("Generated cover.png")


if __name__ == "__main__":
    main()
