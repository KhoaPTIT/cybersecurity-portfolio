from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from dct_helper import IMAGE_SIZE, work_path, write_report


CELL = 256
LABEL_H = 28


def load_tile(path: Path) -> Image.Image:
    if not path.exists():
        return Image.new("RGB", (CELL, CELL), (80, 80, 80))
    return Image.open(path).convert("RGB").resize((CELL, CELL))


def diff_tile(a: Path, b: Path) -> Image.Image:
    if not a.exists() or not b.exists():
        return Image.new("RGB", (CELL, CELL), (80, 80, 80))
    left = np.asarray(Image.open(a).convert("L").resize((IMAGE_SIZE, IMAGE_SIZE)), dtype=np.int16)
    right = np.asarray(Image.open(b).convert("L").resize((IMAGE_SIZE, IMAGE_SIZE)), dtype=np.int16)
    diff = np.clip(np.abs(left - right) * 6, 0, 255).astype(np.uint8)
    return Image.fromarray(diff, mode="L").convert("RGB").resize((CELL, CELL))


def paste_labeled(canvas: Image.Image, tile: Image.Image, x: int, y: int, label: str) -> None:
    draw = ImageDraw.Draw(canvas)
    draw.rectangle((x, y, x + CELL, y + LABEL_H), fill=(25, 25, 25))
    draw.text((x + 8, y + 7), label, fill=(245, 245, 245), font=ImageFont.load_default())
    canvas.paste(tile, (x, y + LABEL_H))


def main() -> None:
    paths = {
        "cover": work_path("cover.png"),
        "stego": work_path("stego.png"),
        "attack": work_path("attacks/composite_attacked.png"),
        "defended": work_path("defended.png"),
    }
    canvas = Image.new("RGB", (CELL * 3, (CELL + LABEL_H) * 2), (235, 235, 235))
    paste_labeled(canvas, load_tile(paths["cover"]), 0, 0, "cover.png")
    paste_labeled(canvas, load_tile(paths["stego"]), CELL, 0, "stego.png")
    paste_labeled(canvas, diff_tile(paths["cover"], paths["stego"]), CELL * 2, 0, "cover vs stego diff x6")
    paste_labeled(canvas, load_tile(paths["attack"]), 0, CELL + LABEL_H, "composite attack")
    paste_labeled(canvas, load_tile(paths["defended"]), CELL, CELL + LABEL_H, "defended.png")
    paste_labeled(canvas, diff_tile(paths["stego"], paths["defended"]), CELL * 2, CELL + LABEL_H, "stego vs defended diff x6")
    canvas.save(work_path("defense_contact_sheet.png"))

    missing = [name for name, path in paths.items() if not path.exists()]
    status = "Defense visual comparison completed" if not missing else "Defense visual comparison incomplete"
    write_report(
        work_path("visual_defense_report.txt"),
        [
            status,
            "Output: defense_contact_sheet.png",
            f"Missing inputs: {', '.join(missing) if missing else 'none'}",
            "Inspect block boundary drift, border fill, blur from interpolation, and recovered alignment.",
        ],
    )
    print(status)
    print("Open defense_contact_sheet.png and compare attack/defended panels before writing observations.")


if __name__ == "__main__":
    main()
