# RELEASE_AFTER_TEST_OK

Chi lam cac buoc nay sau khi da test local OK. Khong push tu dong.

1. Kiem tra image local:

```bash
docker images | grep dct-geo-defense
```

2. Tag image sang DockerHub registry `hackato`:

```bash
docker tag dct-geo-defense.dct-geo-defense.student:latest hackato/dct-geo-defense.dct-geo-defense.student:latest
```

Neu ten image local khac, dung IMAGE ID:

```bash
docker tag <IMAGE_ID> hackato/dct-geo-defense.dct-geo-defense.student:latest
```

3. Push DockerHub:

```bash
docker login
docker push hackato/dct-geo-defense.dct-geo-defense.student:latest
```

4. Sau khi DockerHub co image, moi push file `dct-geo-defense.tar` len GitHub.

5. Khi do nguoi khac moi chay:

```bash
imodule https://github.com/<repo>/raw/main/dct-geo-defense.tar
labtainer dct-geo-defense
```

Luu y: nguoi tao lab test lan dau bang `labtainer -r dct-geo-defense`. Nguoi dung cuoi chi chay `labtainer dct-geo-defense` sau khi image da duoc push len DockerHub `hackato`.
