# TEST_IMODULE_LOCAL

Test file tar nhu nguoi dung moi, sau khi da dong goi `dct-geo-defense.tar`.

```bash
cd ~/labtainer/trunk/scripts/labtainer-student
imodule /duong/dan/dct-geo-defense.tar
labtainer -r dct-geo-defense
```

Sau khi terminal container mo ra, chay tung task:

```bash
python3 calibrate_dct_defense.py --alpha 35 --repeat 5
python3 parameter_sweep.py --alphas 25,35,45 --repeats 5,7
python3 build_geometric_benchmark.py
python3 validate_defense_plan.py
python3 apply_plan_to_config.py

# Sua DEFENSE_PLAN.md / defense_config.py theo quan sat truoc khi chay.
python3 registration_defense.py
python3 visualize_defense.py
python3 validate_defense_memo.py
python3 summary.py
checkwork
stoplab dct-geo-defense
```
